"""VoiceOver Fix (Windows) - mesin inti: baca PDF, decode audio (ffmpeg),
transkripsi offline (whisper.cpp / whisper-cli.exe), pencocokan naskah, gabung take."""
import array
import json
import math
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
import wave
from pathlib import Path

NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
MODEL_URL = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-{}.bin"


class Cancelled(Exception):
    pass


class Pcm:
    """Audio mono 16-bit little-endian. data = bytes, rate = Hz."""
    def __init__(self, data: bytes, rate: int):
        self.data = data
        self.rate = rate

    @property
    def n(self) -> int:
        return len(self.data) // 2


class Seg:
    def __init__(self, start: float, end: float, text: str):
        self.start, self.end, self.text = start, end, text


class Hit:
    def __init__(self, script: str, heard: str, score: float, start: float, end: float):
        self.script, self.heard, self.score, self.start, self.end = script, heard, score, start, end
        self.cs, self.ce = start - 0.05, end + 0.12     # titik potong (dirapikan oleh refine())


# ---------------------------------------------------------------- lokasi file
def base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


def find_tool(name: str) -> str:
    b = base_dir()
    for d in (b / "bin", b):
        for fn in (name + ".exe", name):
            p = d / fn
            if p.is_file():
                return str(p)
    w = shutil.which(name)
    if w:
        return w
    raise FileNotFoundError(f"{name} tidak ditemukan (harus ada di folder 'bin' di samping VoiceOverFix.exe)")


def results_dir() -> Path:
    """Folder 'Hasil' di lokasi yang sama dengan aplikasi (dibuat otomatis).
    Kalau lokasi itu tidak bisa ditulisi, pakai folder cadangan."""
    for d in (base_dir() / "Hasil", Path(os.path.expanduser("~")) / "Documents" / "VoiceOverFix Hasil"):
        try:
            d.mkdir(parents=True, exist_ok=True)
            probe = d / ".tulis"
            probe.write_text("x")
            probe.unlink()
            return d
        except OSError:
            continue
    return Path(os.path.expanduser("~"))


def work_root() -> Path:
    """Folder kerja (model, pengaturan, file sementara). Dipilih yang path-nya ASCII
    supaya aman dibuka whisper-cli.exe."""
    cands = []
    for env, sub in (("LOCALAPPDATA", "VoiceOverFix"), ("PUBLIC", "VoiceOverFix")):
        v = os.environ.get(env)
        if v:
            cands.append(Path(v) / sub)
    cands.append(Path(os.path.expanduser("~")) / "VoiceOverFix")
    cands.append(Path("C:/VoiceOverFix"))
    for c in cands:
        if str(c).isascii():
            try:
                c.mkdir(parents=True, exist_ok=True)
                return c
            except OSError:
                continue
    c = Path(tempfile.gettempdir()) / "VoiceOverFix"
    c.mkdir(parents=True, exist_ok=True)
    return c


# ---------------------------------------------------------------- PDF
def read_pdf(path: str) -> list:
    from pypdf import PdfReader
    r = PdfReader(path)
    t = "\n".join((p.extract_text() or "") for p in r.pages)
    if not t.strip():
        raise ValueError("PDF tidak berisi teks (mungkin hasil scan/gambar)")
    t = re.sub(r"\s+", " ", t.replace("\n", " "))
    return [s.strip() for s in re.split(r"(?<=[.!?])\s+", t) if len(s.strip()) > 3]


# ---------------------------------------------------------------- audio
def _run(cmd, **kw):
    return subprocess.run(cmd, creationflags=NO_WINDOW, **kw)


def decode(path: str, rate: int = 44100) -> Pcm:
    ff = find_tool("ffmpeg")
    r = _run([ff, "-v", "error", "-nostdin", "-i", path, "-vn", "-ac", "1", "-ar", str(rate),
              "-f", "s16le", "pipe:1"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if r.returncode != 0 or not r.stdout:
        msg = r.stderr.decode("utf-8", "replace").strip()[-300:]
        raise RuntimeError(f"Gagal membaca audio '{os.path.basename(path)}': {msg}")
    return Pcm(r.stdout, rate)


def decode_all(paths: list, cancel: threading.Event, on_prog=None, rate: int = 44100) -> Pcm:
    """Gabung beberapa file (urut sesuai daftar) jadi satu garis waktu, jeda 0,5 detik antar file."""
    gap = b"\x00\x00" * (rate // 2)
    chunks = []
    for i, p in enumerate(paths):
        if cancel.is_set():
            raise Cancelled()
        if on_prog:
            on_prog(f"Membaca audio {i + 1}/{len(paths)}: {os.path.basename(p)}", i / len(paths))
        if i:
            chunks.append(gap)
        chunks.append(decode(p, rate).data)
    return Pcm(b"".join(chunks), rate)


def write_wav(path: str, data: bytes, rate: int):
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(data)


def slice_pcm(p: Pcm, s: float, e: float) -> bytes:
    n = p.n
    a = min(max(int(max(0.0, s) * p.rate), 0), n)
    b = min(max(int(e * p.rate), a), n)
    return p.data[a * 2:b * 2]


def fade(data: bytes, rate: int, ms: int = 10) -> bytes:
    a = array.array("h")
    a.frombytes(data)
    n = len(a)
    k = min(int(rate * ms / 1000), n // 2)
    for i in range(k):
        g = i / k
        a[i] = int(a[i] * g)
        a[n - 1 - i] = int(a[n - 1 - i] * g)
    return a.tobytes()


def cut_hit(p: Pcm, h: Hit) -> bytes:
    return fade(slice_pcm(p, h.cs, h.ce), p.rate)


def merge(p: Pcm, hits: list, min_score: float) -> bytes:
    gap = b"\x00\x00" * int(0.15 * p.rate)
    out = []
    for h in hits:
        if h.score >= min_score:
            out.append(cut_hit(p, h))
            out.append(gap)
    return b"".join(out)


# ---------------------------------------------------------------- titik potong presisi
# Timestamp Whisper kurang presisi (sering meleset 0,1-0,3 detik, dan ujung segmen sering
# menempel dengan awal segmen berikutnya). Jadi titik potong digeser ke jeda senyap terdekat.
FR = 0.01  # 10 ms per frame


class Energy:
    def __init__(self, p: Pcm):
        fl = int(p.rate * FR)
        d = p.data
        step = fl * 2
        try:
            import audioop
            rms = [audioop.rms(d[i:i + step], 2) for i in range(0, len(d) - step + 1, step)]
        except ImportError:
            a = array.array("h")
            a.frombytes(d)
            rms = []
            for i in range(0, len(a) - fl + 1, fl):
                seg = a[i:i + fl:4]
                rms.append(math.sqrt(sum(x * x for x in seg) / max(1, len(seg))))
        self.db = [20 * math.log10(r + 1.0) for r in rms]
        self.n = len(self.db)
        if self.n:
            s = sorted(self.db)
            low, high = s[int(self.n * 0.05)], s[min(self.n - 1, int(self.n * 0.95))]
            thr = low + max(6.0, 0.30 * (high - low))
        else:
            thr = 0.0
        self.below = [x < thr for x in self.db]

    def _extent(self, i):
        s = i
        while s > 0 and self.below[s - 1]:
            s -= 1
        e = i
        while e < self.n and self.below[e]:
            e += 1
        return s, e

    def _first_run(self, lo, hi, minlen):
        i, hi = max(0, lo), min(self.n, hi)
        while i < hi:
            if self.below[i]:
                s, e = self._extent(i)
                if e - s >= minlen:
                    return s, e
                i = e
            i += 1
        return None

    def _last_run(self, lo, hi, minlen):
        lo, i = max(0, lo), min(self.n, hi) - 1
        while i >= lo:
            if self.below[i]:
                s, e = self._extent(i)
                if e - s >= minlen:
                    return s, e
                i = s - 1
            else:
                i -= 1
        return None

    def snap_end(self, t: float):
        f = int(t / FR)
        for minlen in (12, 5):               # jeda >=120 ms dulu, baru jeda pendek
            r = self._first_run(f - 5, f + 50, minlen)
            if r:
                return (r[0] + min(6, (r[1] - r[0]) // 2)) * FR
        lo, hi = max(0, f), min(self.n, f + 30)
        if hi > lo:
            return (min(range(lo, hi), key=self.db.__getitem__) + 0.5) * FR
        return None

    def snap_start(self, t: float):
        f = int(t / FR)
        for minlen in (12, 5):
            r = self._last_run(f - 50, f + 6, minlen)
            if r:
                return (r[1] - min(6, (r[1] - r[0]) // 2)) * FR
        lo, hi = max(0, f - 30), min(self.n, f + 4)
        if hi > lo:
            return (min(range(lo, hi), key=self.db.__getitem__) + 0.5) * FR
        return None


def refine(p: Pcm, hits: list):
    """Geser titik potong tiap take ke jeda senyap terdekat + beri sedikit napas."""
    en = Energy(p)
    for h in hits:
        if h.score <= 0:
            continue
        a, b = en.snap_start(h.start), en.snap_end(h.end)
        if a is not None and b is not None and b - a > 0.1:
            h.cs, h.ce = a, b


# ---------------------------------------------------------------- model
def download_model(name: str, on_prog, cancel: threading.Event) -> str:
    d = work_root() / "models"
    d.mkdir(parents=True, exist_ok=True)
    f = d / f"ggml-{name}.bin"
    if f.exists() and f.stat().st_size > 1_000_000:
        return str(f)
    tmp = d / f"ggml-{name}.part"
    tries = 0
    while True:
        if cancel.is_set():
            raise Cancelled()
        try:
            start = tmp.stat().st_size if tmp.exists() else 0
            req = urllib.request.Request(MODEL_URL.format(name), headers={"User-Agent": "VoiceOverFix/1.0"})
            if start > 0:
                req.add_header("Range", f"bytes={start}-")
            try:
                resp = urllib.request.urlopen(req, timeout=30)
            except urllib.error.HTTPError as e:
                if e.code == 416:       # sudah lengkap
                    break
                if e.code == 404:
                    raise RuntimeError(f"Model '{name}' tidak ada di HuggingFace (coba: tiny, base, small, medium)")
                raise
            with resp:
                if resp.status == 200 and start > 0:    # server tidak mendukung lanjut -> ulang dari awal
                    start = 0
                total = start + int(resp.headers.get("Content-Length") or 0)
                done, last = start, -1
                with open(tmp, "ab" if start > 0 else "wb") as o:
                    while True:
                        if cancel.is_set():
                            raise Cancelled()
                        buf = resp.read(65536)
                        if not buf:
                            break
                        o.write(buf)
                        done += len(buf)
                        pc = int(done * 100 / total) if total > 0 else 0
                        if pc != last:
                            last = pc
                            on_prog(pc)
            break
        except (OSError, urllib.error.URLError):
            tries += 1
            if tries > 40:
                raise
            time.sleep(2)
    os.replace(tmp, f)
    return str(f)


# ---------------------------------------------------------------- transkripsi
def transcribe(pcm: Pcm, model: str, lang: str, cancel: threading.Event, on_prog) -> list:
    """Jalankan whisper-cli.exe (whisper.cpp) pada seluruh rekaman; kembalikan daftar Seg."""
    ff, cli = find_tool("ffmpeg"), find_tool("whisper-cli")
    tmp = Path(tempfile.mkdtemp(prefix="vof_", dir=str(work_root())))
    try:
        w16 = tmp / "audio16k.wav"
        r = _run([ff, "-v", "error", "-nostdin", "-y", "-f", "s16le", "-ar", str(pcm.rate), "-ac", "1",
                  "-i", "pipe:0", "-ar", "16000", "-ac", "1", "-c:a", "pcm_s16le", str(w16)],
                 input=pcm.data, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if r.returncode != 0:
            raise RuntimeError("Gagal menyiapkan audio 16 kHz: " + r.stderr.decode("utf-8", "replace")[-300:])

        out_prefix = tmp / "hasil"
        threads = max(1, min(8, (os.cpu_count() or 4)))
        cmd = [cli, "-m", model, "-f", str(w16), "-l", lang or "id", "-oj", "-of", str(out_prefix),
               "-pp", "-mc", "0", "-t", str(threads)]
        proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True,
                                encoding="utf-8", errors="replace", creationflags=NO_WINDOW)
        t0 = time.time()
        tail = []
        rx = re.compile(r"progress\s*=\s*(\d+)%")
        on_prog("Memuat model…", 0.0)
        for line in proc.stderr:
            if cancel.is_set():
                proc.kill()
                raise Cancelled()
            tail = (tail + [line.strip()])[-12:]
            m = rx.search(line)
            if m:
                pc = int(m.group(1))
                el = time.time() - t0
                eta = int(el * (100 - pc) / pc) if pc >= 2 else -1
                sisa = f" — sisa ±{eta // 60} mnt {eta % 60} dtk" if eta >= 0 else ""
                on_prog(f"Mengubah suara jadi teks: {pc}%{sisa}", pc / 100)
        code = proc.wait()
        if cancel.is_set():
            raise Cancelled()
        jf = Path(str(out_prefix) + ".json")
        if code != 0 or not jf.exists():
            raise RuntimeError("whisper-cli gagal (kode %s):\n%s" % (code, "\n".join(tail)))
        with open(jf, encoding="utf-8", errors="replace") as f:
            data = json.load(f)
        segs = []
        for t in data.get("transcription", []):
            o = t.get("offsets") or {}
            txt = (t.get("text") or "").strip()
            if txt:
                segs.append(Seg(o.get("from", 0) / 1000.0, o.get("to", 0) / 1000.0, txt))
        on_prog("Transkripsi selesai", 1.0)
        return segs
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


# ---------------------------------------------------------------- pencocokan
def norm(s: str) -> str:
    return re.sub(r"[\W_]+", " ", s.lower()).strip()


try:
    from rapidfuzz.distance import Levenshtein as _Lev

    def sim(a: str, b: str) -> float:
        """a, b sudah dinormalisasi. 1 - jarak_Levenshtein / panjang_terpanjang."""
        if not a or not b:
            return 0.0
        return _Lev.normalized_similarity(a, b)
except Exception:  # cadangan murni-Python (lambat, hanya jika rapidfuzz tidak ada)
    def sim(a: str, b: str) -> float:
        if not a or not b:
            return 0.0
        p = list(range(len(b) + 1))
        for i in range(1, len(a) + 1):
            c = [i] + [0] * len(b)
            for j in range(1, len(b) + 1):
                c[j] = min(p[j] + 1, c[j - 1] + 1, p[j - 1] + (0 if a[i - 1] == b[j - 1] else 1))
            p = c
        return 1.0 - p[len(b)] / max(len(a), len(b))


def match(script: list, segs: list) -> list:
    """Tiap kalimat naskah -> take (1-3 segmen berurutan) yang paling mirip; seri -> ambil yang paling akhir."""
    ns = [norm(s.text) for s in segs]
    hits = []
    for s in script:
        n = norm(s)
        best = Hit(s, "", 0.0, 0.0, 0.0)
        L = len(n)
        if L:
            for i in range(len(segs)):
                for w in (1, 2, 3):
                    if i + w > len(segs):
                        break
                    txt = " ".join(x for x in ns[i:i + w] if x)
                    if len(txt) < L * 0.5 or len(txt) > L * 2:
                        continue
                    sc = sim(n, txt)
                    if sc >= best.score:
                        heard = " ".join(x.text for x in segs[i:i + w]).strip()
                        best = Hit(s, heard, sc, segs[i].start, segs[i + w - 1].end)
        hits.append(best)
    return hits

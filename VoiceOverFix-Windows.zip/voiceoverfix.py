"""VoiceOver Fix - versi Windows."""
import json
import os
import queue
import sys
import threading
import time
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

import core

try:
    import winsound
except ImportError:  # bukan Windows (hanya untuk uji coba)
    winsound = None

AUDIO_TYPES = [("Audio / video", "*.mp3 *.wav *.m4a *.aac *.ogg *.opus *.flac *.wma *.amr *.mp4 *.mkv *.mov *.webm *.3gp"),
               ("Semua file", "*.*")]


def row_color(score: float, thr: float) -> str:
    if score >= thr:
        return "#C8E6C9"      # hijau
    if score >= thr - 0.2:
        return "#FFF59D"      # kuning
    return "#FFCDD2"          # merah


class App:
    def __init__(self, root: tk.Tk):
        self.root = root
        root.title("VoiceOver Fix")
        root.geometry("920x820")
        root.minsize(700, 600)
        try:
            ico = (Path(getattr(sys, "_MEIPASS", core.base_dir())) / "icon.ico")
            if ico.exists():
                root.iconbitmap(default=str(ico))
        except Exception:
            pass

        self.cfg_path = core.work_root() / "settings.json"
        self.cfg = {}
        try:
            self.cfg = json.loads(self.cfg_path.read_text(encoding="utf-8"))
        except Exception:
            pass

        self.script = []
        self.audios = []          # daftar path
        self.pcm = None
        self.hits = []
        self.busy = False
        self.cancel = threading.Event()
        self.q = queue.Queue()
        self.t_start = 0.0
        self.last_saved = None

        # bawaan: folder "Hasil" di samping aplikasi (dibuat otomatis)
        self.out_dir = self.cfg.get("out") or str(core.results_dir())
        Path(self.out_dir).mkdir(parents=True, exist_ok=True)

        self.var_model = tk.StringVar(value=self.cfg.get("model", "small"))
        self.var_lang = tk.StringVar(value=self.cfg.get("lang", "id"))
        self.var_thr = tk.DoubleVar(value=self.cfg.get("thr", 0.75))
        self.var_status = tk.StringVar(value="")
        self.var_elapsed = tk.StringVar(value="")
        self.var_pdf = tk.StringVar(value="")
        self.var_aud = tk.StringVar(value="")
        self.var_out = tk.StringVar(value="")
        self.var_thr_lbl = tk.StringVar()

        self.build_ui()
        self.refresh_labels()
        self.root.after(100, self.poll)
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

    # ------------------------------------------------------------ UI
    def build_ui(self):
        top = ttk.Frame(self.root, padding=12)
        top.pack(fill="x")
        ttk.Label(top, text="VoiceOver Fix", font=("Segoe UI", 16, "bold")).pack(anchor="w", pady=(0, 8))

        ttk.Button(top, text="Pilih Naskah PDF", command=self.pick_pdf).pack(fill="x")
        ttk.Label(top, textvariable=self.var_pdf, wraplength=860, justify="left").pack(anchor="w", pady=(2, 8))

        ttk.Button(top, text="Pilih Audio Rekaman (boleh banyak)", command=self.pick_audio).pack(fill="x")
        ttk.Label(top, textvariable=self.var_aud, wraplength=860, justify="left").pack(anchor="w", pady=(2, 8))

        ttk.Button(top, text="Ganti Folder Simpan (bawaan: folder Hasil di samping aplikasi)", command=self.pick_out).pack(fill="x")
        ttk.Label(top, textvariable=self.var_out, wraplength=860, justify="left").pack(anchor="w", pady=(2, 8))

        opt = ttk.Frame(top)
        opt.pack(fill="x", pady=(0, 4))
        ttk.Label(opt, text="Model:").pack(side="left")
        ttk.Combobox(opt, textvariable=self.var_model, width=14,
                     values=["tiny", "base", "small", "medium"]).pack(side="left", padx=(4, 4))
        ttk.Label(opt, text="(small paling akurat; medium lebih akurat tapi lambat)").pack(side="left", padx=(0, 16))
        ttk.Label(opt, text="Bahasa:").pack(side="left")
        ttk.Entry(opt, textvariable=self.var_lang, width=5).pack(side="left", padx=4)

        ttk.Label(top, textvariable=self.var_thr_lbl).pack(anchor="w")
        ttk.Scale(top, from_=0.5, to=0.95, variable=self.var_thr, command=self.on_thr).pack(fill="x", pady=(0, 8))

        btns = ttk.Frame(top)
        btns.pack(fill="x")
        self.btn_go = ttk.Button(btns, text="Proses", command=self.start)
        self.btn_go.pack(side="left", fill="x", expand=True)
        self.btn_cancel = ttk.Button(btns, text="Batal", command=self.on_cancel, state="disabled")
        self.btn_cancel.pack(side="left", padx=(8, 0))

        ttk.Label(top, textvariable=self.var_status, wraplength=860, justify="left").pack(anchor="w", pady=(8, 0))
        self.bar = ttk.Progressbar(top, mode="determinate", maximum=100)
        self.bar.pack(fill="x", pady=(4, 0))
        ttk.Label(top, textvariable=self.var_elapsed, foreground="#555").pack(anchor="w")

        mid = ttk.Frame(self.root, padding=(12, 0, 12, 0))
        mid.pack(fill="both", expand=True)
        self.txt = tk.Text(mid, wrap="word", font=("Segoe UI", 11), state="disabled", cursor="arrow",
                           borderwidth=1, relief="solid", padx=6, pady=6)
        sb = ttk.Scrollbar(mid, orient="vertical", command=self.txt.yview)
        self.txt.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.txt.pack(side="left", fill="both", expand=True)
        self.txt.tag_configure("small", font=("Segoe UI", 9))
        self.txt.tag_configure("play", foreground="#1a56c4", underline=True, font=("Segoe UI", 10, "bold"))

        bot = ttk.Frame(self.root, padding=12)
        bot.pack(fill="x")
        self.btn_save = ttk.Button(bot, text="Gabung & Simpan", command=self.save, state="disabled")
        self.btn_save.pack(side="left", fill="x", expand=True)
        self.btn_open = ttk.Button(bot, text="Buka Folder Hasil", command=self.open_folder, state="disabled")
        self.btn_open.pack(side="left", padx=(8, 0))

    def refresh_labels(self):
        self.var_out.set("Hasil disimpan di: " + self.out_dir)
        self.var_thr_lbl.set(f"Kemiripan minimum: {int(self.var_thr.get() * 100)}%")

    # ------------------------------------------------------------ pilihan file
    def pick_pdf(self):
        p = filedialog.askopenfilename(title="Pilih naskah PDF", filetypes=[("PDF", "*.pdf")])
        if not p:
            return
        try:
            self.script = core.read_pdf(p)
            self.var_pdf.set(f"Naskah: {os.path.basename(p)} ({len(self.script)} kalimat)")
            self.var_status.set("Naskah dimuat")
        except Exception as e:
            self.var_status.set(f"Gagal baca PDF: {e}")

    def pick_audio(self):
        ps = filedialog.askopenfilenames(title="Pilih audio rekaman", filetypes=AUDIO_TYPES)
        if not ps:
            return
        self.audios = sorted(ps, key=lambda x: os.path.basename(x).lower())
        self.hits = []
        self.pcm = None
        self.render_hits()
        self.var_aud.set(f"{len(self.audios)} audio, digabung berurutan sesuai nama:\n" +
                         "\n".join("• " + os.path.basename(x) for x in self.audios))
        self.var_status.set(f"{len(self.audios)} audio dipilih")

    def pick_out(self):
        d = filedialog.askdirectory(title="Pilih folder simpan", initialdir=self.out_dir)
        if d:
            self.out_dir = d
            self.save_cfg()
            self.refresh_labels()

    def save_cfg(self):
        try:
            self.cfg_path.write_text(json.dumps({
                "out": self.out_dir, "model": self.var_model.get().strip(),
                "lang": self.var_lang.get().strip(), "thr": round(self.var_thr.get(), 3)}), encoding="utf-8")
        except Exception:
            pass

    # ------------------------------------------------------------ proses
    def start(self):
        if self.busy:
            return
        if not self.script:
            self.var_status.set("Pilih naskah PDF dulu")
            return
        if not self.audios:
            self.var_status.set("Pilih audio rekaman dulu")
            return
        self.save_cfg()
        self.busy = True
        self.cancel.clear()
        self.t_start = time.time()
        self.btn_go.config(state="disabled")
        self.btn_cancel.config(state="normal")
        self.btn_save.config(state="disabled")
        self.hits = []
        self.render_hits()
        model, lang, audios, script = self.var_model.get().strip() or "small", self.var_lang.get().strip() or "id", \
            list(self.audios), list(self.script)
        threading.Thread(target=self.worker, args=(model, lang, audios, script), daemon=True).start()

    def worker(self, model, lang, audios, script):
        q = self.q
        try:
            q.put(("status", "Membaca audio…", None))
            pcm = core.decode_all(audios, self.cancel, lambda m, f: q.put(("status", m, f)))
            q.put(("status", "Mengunduh model (sekali saja)…", None))
            mf = core.download_model(model, lambda pc: q.put(("status", f"Mengunduh model… {pc}%", pc / 100)), self.cancel)
            segs = core.transcribe(pcm, mf, lang, self.cancel, lambda m, f: q.put(("status", m, f)))
            q.put(("status", "Mencocokkan dengan naskah…", None))
            hits = core.match(script, segs)
            q.put(("status", "Merapikan titik potong…", None))
            core.refine(pcm, hits)
            q.put(("done", pcm, hits))
        except core.Cancelled:
            q.put(("fail", "Dibatalkan"))
        except Exception as e:
            q.put(("fail", f"Error: {e}"))

    def poll(self):
        try:
            while True:
                m = self.q.get_nowait()
                if m[0] == "status":
                    self.var_status.set(m[1])
                    if m[2] is None:
                        self.bar.config(mode="indeterminate")
                        self.bar.start(15)
                    else:
                        self.bar.stop()
                        self.bar.config(mode="determinate", value=m[2] * 100)
                elif m[0] == "done":
                    self.pcm, self.hits = m[1], m[2]
                    self.var_status.set("Selesai. Cek hasil di bawah.")
                    self.finish()
                    self.render_hits()
                    self.btn_save.config(state="normal" if self.hits else "disabled")
                    if self.hits:
                        self.save()      # simpan otomatis ke folder Hasil
                        self.var_status.set("Selesai. " + self.var_status.get())
                elif m[0] == "fail":
                    self.var_status.set(m[1])
                    self.finish()
        except queue.Empty:
            pass
        if self.busy:
            s = int(time.time() - self.t_start)
            self.var_elapsed.set("Berjalan: %02d:%02d (angka ini terus berjalan = aplikasi tidak macet)" % (s // 60, s % 60))
        self.root.after(200, self.poll)

    def finish(self):
        self.busy = False
        self.bar.stop()
        self.bar.config(mode="determinate", value=0)
        self.var_elapsed.set("")
        self.btn_go.config(state="normal")
        self.btn_cancel.config(state="disabled")

    def on_cancel(self):
        self.cancel.set()
        self.var_status.set("Membatalkan…")

    # ------------------------------------------------------------ hasil
    def render_hits(self):
        t = self.txt
        t.config(state="normal")
        t.delete("1.0", "end")
        thr = self.var_thr.get()
        for i, h in enumerate(self.hits):
            row, link = f"row{i}", f"play{i}"
            t.tag_configure(row, background=row_color(h.score, thr), lmargin1=6, lmargin2=6, rmargin=6, spacing1=2, spacing3=2)
            t.insert("end", h.script + "\n", (row,))
            if h.heard and h.score < 0.98:
                t.insert("end", f"Terdengar: {h.heard}\n", (row, "small"))
            t.insert("end", f"{int(h.score * 100)}%   ", (row, "small"))
            t.insert("end", "▶ Putar", (row, "play", link))
            t.insert("end", "\n", (row,))
            t.insert("end", "\n")
            t.tag_bind(link, "<Button-1>", lambda e, i=i: self.play(i))
            t.tag_bind(link, "<Enter>", lambda e: t.config(cursor="hand2"))
            t.tag_bind(link, "<Leave>", lambda e: t.config(cursor="arrow"))
        t.config(state="disabled")

    def on_thr(self, _=None):
        self.refresh_labels()
        thr = self.var_thr.get()
        for i, h in enumerate(self.hits):
            self.txt.tag_configure(f"row{i}", background=row_color(h.score, thr))

    def play(self, i: int):
        if not self.pcm or winsound is None:
            return
        h = self.hits[i]
        data = core.cut_hit(self.pcm, h)
        if not data:
            return
        try:
            f = core.work_root() / "preview.wav"
            winsound.PlaySound(None, winsound.SND_PURGE)
            core.write_wav(str(f), data, self.pcm.rate)
            winsound.PlaySound(str(f), winsound.SND_FILENAME | winsound.SND_ASYNC)
        except Exception as e:
            self.var_status.set(f"Gagal memutar: {e}")

    def save(self):
        try:
            data = core.merge(self.pcm, self.hits, self.var_thr.get() - 0.2)
            Path(self.out_dir).mkdir(parents=True, exist_ok=True)
            f = Path(self.out_dir) / f"voiceover_fixed_{int(time.time() * 1000)}.wav"
            core.write_wav(str(f), data, self.pcm.rate)
            self.last_saved = f
            self.var_status.set(f"Tersimpan: {f} (kalimat merah dilewati)")
            self.btn_open.config(state="normal")
        except Exception as e:
            self.var_status.set(f"Error: {e}")

    def open_folder(self):
        try:
            if self.last_saved and hasattr(os, "startfile"):
                os.startfile(str(self.last_saved.parent))
        except Exception:
            pass

    def on_close(self):
        if self.busy and not messagebox.askyesno("VoiceOver Fix", "Proses masih berjalan. Tutup aplikasi?"):
            return
        self.cancel.set()
        if winsound:
            try:
                winsound.PlaySound(None, winsound.SND_PURGE)
            except Exception:
                pass
        self.root.destroy()


def main():
    try:
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass
    root = tk.Tk()
    try:
        core.find_tool("ffmpeg")
        core.find_tool("whisper-cli")
    except FileNotFoundError as e:
        root.withdraw()
        messagebox.showerror("VoiceOver Fix", str(e))
        return
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
